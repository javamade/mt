document.getElementById('registrationForm').addEventListener('submit', function(e) {
  e.preventDefault();

  // Get form values
  const username = document.getElementById('username').value;
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  // Store the values in local storage (for simplicity)
  localStorage.setItem('username', username);
  localStorage.setItem('email', email);
  localStorage.setItem('password', password);

  // Hide the registration form and show the login form
  document.getElementById('registrationForm').style.display = 'none';
  document.getElementById('loginForm').style.display = 'block';
});

document.getElementById('login').addEventListener('submit', function(e) {
  e.preventDefault();

  // Get login values
  const loginUsername = document.getElementById('loginUsername').value;
  const loginPassword = document.getElementById('loginPassword').value;

  // Retrieve stored values
  const storedUsername = localStorage.getItem('username');
  const storedPassword = localStorage.getItem('password');

  // Check if the entered login values match the stored values
  if (loginUsername === storedUsername && loginPassword === storedPassword) {
    alert('Login successful!');
  } else {
    alert('Invalid credentials. Please try again.');
  }
});
